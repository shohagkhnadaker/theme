export default ({children}) => {
    return <div className="rishi-ad_main-content-wrapper">{children}</div>
}